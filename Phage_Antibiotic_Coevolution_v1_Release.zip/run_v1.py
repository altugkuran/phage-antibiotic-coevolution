"""Reproducible illustrative scenarios; no organism-specific or clinical parameters."""
import csv
from dataclasses import replace
from pathlib import Path
import numpy as np
from v1 import Parameters,simulate

SCENARIOS = {
    'phage_only_single':(0.0,(6.,0.)),
    'low_antibiotic_single':(.10,(6.,0.)),
    'high_antibiotic_single':(.55,(6.,0.)),
    'low_antibiotic_cocktail':(.10,(3.,3.)),
    'high_antibiotic_cocktail':(.55,(3.,3.)),
    'antibiotic_only_low':(.10,(0.,0.)),
    'antibiotic_only_high':(.55,(0.,0.)),
    'untreated':(0.,(0.,0.)),
}

def main():
    folder=Path(__file__).resolve().parent
    out=folder/'results_v1.csv'
    b0=np.array([40.,10.,25.,8.,15.,2.])
    with out.open('w',newline='') as fh:
        writer=csv.writer(fh)
        writer.writerow(['scenario','step','S_Fplus','S_Fminus','I_Fplus','I_Fminus','R_Fplus','R_Fminus','phage_1','phage_2','bacterial_total','phage_total'])
        for name,(antibiotic,phages) in SCENARIOS.items():
            p=Parameters(antibiotic=antibiotic)
            b,f=simulate(b0,np.array(phages),p,steps=60)
            for i,(bb,ff) in enumerate(zip(b,f)):
                writer.writerow([name,i,*bb,*ff,bb.sum(),ff.sum()])
    print(f'Wrote {out}')
if __name__=='__main__':main()

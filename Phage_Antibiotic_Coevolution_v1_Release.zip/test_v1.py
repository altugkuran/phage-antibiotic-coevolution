import numpy as np
import pytest
from v1 import Parameters,step,simulate

def test_zero_phages_no_infections():
    b,f,d=step(np.ones(6)*10,np.zeros(2),Parameters())
    assert d['infections'].sum()==0 and np.all(f==0)

def test_aggregate_loss():
    p=Parameters(free_phage_loss=.25,weights={k:0 for k in Parameters().weights})
    b,f,d=step(np.zeros(6),np.array([100.,80.]),p)
    assert np.allclose(f,[75,60])

def test_defense_and_independent_resistance():
    p=Parameters(defense=np.ones((6,2)),independent_resistance=np.ones(6))
    b,f,d=step(np.ones(6)*10,np.ones(2)*5,p)
    assert d['infections'].sum()==0

def test_infection_consumption_bounded():
    p=Parameters(adsorption=np.array([10.,10.]))
    b,f,d=step(np.ones(6)*100,np.array([1.,2.]),p)
    assert np.all(d['consumed']<=np.array([1.,2.])+1e-10)
    assert np.all(b>=0) and np.all(f>=0)

def test_invalid_coefficients():
    with pytest.raises(ValueError): Parameters(free_phage_loss=1.2).validate()
    with pytest.raises(ValueError): Parameters(defense=np.ones((5,2))).validate()

def test_reproducibility_and_nonnegative():
    p=Parameters()
    a,b=simulate(np.ones(6)*20,np.array([3.,5.]),p,steps=20)
    c,d=simulate(np.ones(6)*20,np.array([3.,5.]),p,steps=20)
    assert np.array_equal(a,c) and np.array_equal(b,d)
    assert np.all(np.isfinite(a)) and np.all(a>=0) and np.all(np.isfinite(b)) and np.all(b>=0)

def test_identity_hgt_and_mutation_conserve_transition_mass():
    p=Parameters(bacteria_growth=np.zeros(6),antibiotic=0.,adsorption=np.zeros(2))
    b,f,_=step(np.arange(1.,7.),np.zeros(2),p)
    assert np.allclose(b,np.arange(1.,7.))

"""Exploratory, uncalibrated phage-antibiotic-bacteria population model v1.0.

Dimensionless discrete-time dynamics. NOT a treatment predictor, dosing model,
validated biological simulator, or laboratory protocol. Parameters are illustrative.
"""
from dataclasses import dataclass, field
import numpy as np

STATES = ('S_Fplus','S_Fminus','I_Fplus','I_Fminus','R_Fplus','R_Fminus')
MECHANISMS = ('phage','defense','independent_resistance','biofilm','immunity','hgt',
              'epistasis','metabolic_cost','bottleneck','mutation','antibiotic')


def _array(name, value, shape, low=0.0, high=None):
    x = np.asarray(value, dtype=float)
    if x.shape != shape or not np.all(np.isfinite(x)) or np.any(x < low) or (high is not None and np.any(x > high)):
        raise ValueError(f'{name}: expected finite shape {shape}, range [{low},{high}]')
    return x


@dataclass
class Parameters:
    bacteria_growth: np.ndarray = field(default_factory=lambda: np.full(6, 0.12))
    antibiotic_sensitivity: np.ndarray = field(default_factory=lambda: np.array([1.,1.,.5,.5,.1,.1]))
    defense: np.ndarray = field(default_factory=lambda: np.zeros((6,2)))
    independent_resistance: np.ndarray = field(default_factory=lambda: np.array([0.,1.,0.,1.,0.,1.]))
    host_range: np.ndarray = field(default_factory=lambda: np.ones((6,2)))
    adsorption: np.ndarray = field(default_factory=lambda: np.full(2, 0.003))
    burst: np.ndarray = field(default_factory=lambda: np.array([5.,5.]))
    free_phage_loss: float = 0.10  # aggregate natural + non-natural loss fraction per step
    antibiotic: float = 0.0  # abstract intensity, NOT concentration or dose
    carrying_capacity: float = 1000.0
    weights: dict = field(default_factory=lambda: {key: 1.0 for key in MECHANISMS})
    biofilm_protection: np.ndarray = field(default_factory=lambda: np.zeros(6))
    immunity_pressure: np.ndarray = field(default_factory=lambda: np.zeros(2))
    metabolic_cost: np.ndarray = field(default_factory=lambda: np.zeros(6))
    hgt_transition: np.ndarray = field(default_factory=lambda: np.eye(6))
    mutation_transition: np.ndarray = field(default_factory=lambda: np.eye(6))
    epistasis_effect: np.ndarray = field(default_factory=lambda: np.zeros((6,2)))
    bottleneck_fraction: float = 0.0
    seed: int = 7

    def validate(self):
        for key in MECHANISMS:
            if key not in self.weights or not np.isfinite(self.weights[key]) or not 0 <= self.weights[key] <= 1:
                raise ValueError(f'weights[{key}] must be in [0,1]')
        if set(self.weights) != set(MECHANISMS):
            raise ValueError('weights must specify exactly the declared mechanisms')
        for name in ('bacteria_growth','antibiotic_sensitivity','independent_resistance',
                     'biofilm_protection','metabolic_cost'):
            _array(name,getattr(self,name),(6,),high=1 if name!='bacteria_growth' else None)
        for name in ('defense','host_range'):
            _array(name,getattr(self,name),(6,2),high=1)
        _array('epistasis_effect',self.epistasis_effect,(6,2),low=-1,high=1)
        for name in ('adsorption','burst','immunity_pressure'):
            _array(name,getattr(self,name),(2,),high=1 if name=='immunity_pressure' else None)
        for name in ('hgt_transition','mutation_transition'):
            x=_array(name,getattr(self,name),(6,6),high=1)
            if not np.allclose(x.sum(axis=0),1.,atol=1e-10,rtol=0):
                raise ValueError(f'{name} columns must sum to one')
        for name in ('free_phage_loss','bottleneck_fraction'):
            x=getattr(self,name)
            if not np.isfinite(x) or not 0<=x<=1: raise ValueError(f'{name} must be in [0,1]')
        if not np.isfinite(self.antibiotic) or self.antibiotic<0: raise ValueError('antibiotic must be nonnegative')
        if not np.isfinite(self.carrying_capacity) or self.carrying_capacity<=0: raise ValueError('carrying_capacity must be positive')
        return self


def step(bacteria, phages, p: Parameters):
    """One synchronous step; bounded infections, explicit virion losses and births.

    Counts are abstract units. A phage that infects is removed from the free pool;
    burst output is released after the step. No implied real-time kinetics.
    """
    p.validate()
    b=_array('bacteria',bacteria,(6,)).copy()
    f=_array('phages',phages,(2,)).copy()
    w=p.weights
    # Mechanism switches interpolate from no effect to parameterized effect.
    defense_factor=1-w['defense']*p.defense
    independent_factor=1-w['independent_resistance']*p.independent_resistance[:,None]
    biofilm_factor=1-w['biofilm']*p.biofilm_protection[:,None]
    epistasis_factor=np.clip(1+w['epistasis']*p.epistasis_effect,0,2)
    effective_host=np.clip(p.host_range*defense_factor*independent_factor*biofilm_factor*epistasis_factor,0,1)
    pressure=w['phage']*effective_host*p.adsorption[None,:]*f[None,:]
    total_pressure=pressure.sum(axis=1)
    infection_probability=-np.expm1(-total_pressure)
    # Distribute each infected host across phage strains; at most one infection per host.
    share=np.divide(pressure,total_pressure[:,None],out=np.zeros_like(pressure),where=total_pressure[:,None]>0)
    infections=b[:,None]*infection_probability[:,None]*share
    infected=infections.sum(axis=1)
    survivors=b-infected
    # Growth and antibiotic mortality are independent abstract terms.
    crowding=max(0.,1.-survivors.sum()/p.carrying_capacity)
    growth=survivors*p.bacteria_growth*crowding*(1-w['metabolic_cost']*p.metabolic_cost)
    after=(survivors+growth)*np.exp(-w['antibiotic']*p.antibiotic*p.antibiotic_sensitivity)
    after=p.hgt_transition @ after * w['hgt'] + after*(1-w['hgt'])
    after=p.mutation_transition @ after * w['mutation'] + after*(1-w['mutation'])
    after=after*(1-w['bottleneck']*p.bottleneck_fraction)
    # A single aggregate environmental loss coefficient covers natural/unnatural decay.
    free_survivors=f*(1-p.free_phage_loss)
    # Consumption cannot exceed available virions: infection events capped by pool.
    # This simple encounter model uses free phage as encounter intensity, and thus
    # caps consumption by proportional scaling when necessary.
    consumed=infections.sum(axis=0)
    scale=np.minimum(1.,np.divide(f,consumed,out=np.ones_like(f),where=consumed>0))
    if np.any(scale<1):
        # Recalculate host losses consistently after capping by virion availability.
        infections=infections*scale[None,:]
        infected=infections.sum(axis=1)
        survivors=b-infected
        growth=survivors*p.bacteria_growth*crowding*(1-w['metabolic_cost']*p.metabolic_cost)
        after=(survivors+growth)*np.exp(-w['antibiotic']*p.antibiotic*p.antibiotic_sensitivity)
        after=p.hgt_transition @ after*w['hgt']+after*(1-w['hgt'])
        after=p.mutation_transition @ after*w['mutation']+after*(1-w['mutation'])
        after=after*(1-w['bottleneck']*p.bottleneck_fraction)
        consumed=infections.sum(axis=0)
    # Environmental loss applies to unconsumed free particles; immune clearance is separate.
    remaining=np.maximum(f-consumed,0)*(1-p.free_phage_loss)
    remaining*=1-w['immunity']*p.immunity_pressure
    produced=infections.sum(axis=0)*p.burst
    next_phages=remaining+produced
    return after,next_phages,{'infections':infections,'consumed':consumed,'produced':produced,
                              'free_loss':(f-consumed)*p.free_phage_loss,'effective_host':effective_host}


def simulate(bacteria,phages,p,steps=100):
    if not isinstance(steps,int) or steps<0: raise ValueError('steps must be a nonnegative integer')
    b=_array('bacteria',bacteria,(6,)).copy()
    f=_array('phages',phages,(2,)).copy()
    bh=[b.copy()]; fh=[f.copy()]
    for _ in range(steps):
        b,f,_=step(b,f,p)
        bh.append(b.copy());fh.append(f.copy())
    return np.stack(bh),np.stack(fh)
